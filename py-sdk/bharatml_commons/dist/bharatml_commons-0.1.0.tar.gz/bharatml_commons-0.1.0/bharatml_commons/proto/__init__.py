"""
Protobuf definitions for BharatML Stack

This package contains the protobuf message definitions and generated Python code
for gRPC communication across all BharatML Stack SDKs.
"""

__version__ = "0.1.0" 